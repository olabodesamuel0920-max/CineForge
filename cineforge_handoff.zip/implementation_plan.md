# Implementation Plan - Cinematic Edit Fracture Engine & Velocity Ramping

We will upgrade the CineForge rendering pipeline from a linear layout to a dynamic, beat-synced montage system. This will match the premium cinematic pacing of the reference videos (e.g. BMW edits) by implementing the Fracture Engine, velocity speed mappings, dark-mode grading presets, and filtering out structural placeholder text.

## Proposed Changes

### 1. Worker Blueprint Type Configuration

#### [MODIFY] [blueprint.ts](file:///c:/Users/colds/Documents/GitHub/CineForge/infrastructure/render-gcp/types/blueprint.ts)
- Add optional `sourceStart` and `sourceEnd` fields to the `TimelineBlock` interface. This separates the output timeline conformed boundaries from the source clip trim positions.

### 2. FFmpeg Filter Complex Compiler

#### [MODIFY] [ffmpeg.ts](file:///c:/Users/colds/Documents/GitHub/CineForge/infrastructure/render-gcp/ffmpeg.ts)
- Update `buildFilterComplex` to trim input streams utilizing `block.sourceStart` and `block.sourceEnd` if defined; otherwise default to `block.start` and `block.end`.
- Enhance the `luxury-demon-reveal` cinematic color grade to apply high contrast (`contrast=1.35`), dark shadows (`brightness=-0.07`), punchy saturation (`saturation=1.25`), and warm/cool color balance balancing (`colorbalance=rm=0.10:gm=-0.05:bm=0.15`).
- Boost the `vignette` aesthetic boundary filter to `0.40`.

### 3. GCP Render Worker Server

#### [MODIFY] [server.ts](file:///c:/Users/colds/Documents/GitHub/CineForge/infrastructure/render-gcp/server.ts)
- Implement the **Fracture Engine** inside both `/render` and `/render/preview` POST handlers:
  - After calculating conformed boundaries snapped to beat transients, check if the block is a high-energy phase or if the selected mode is a dynamic edit.
  - If suitable, slice the conformed block into sub-segments corresponding to the transient beat boundaries.
  - For each sub-segment, pick a deterministic, pseudo-random start time in the source video:
    `sourceStart = (seed * maxPossibleStart) % (duration - sourceSliceDuration)`.
  - Push these fractured sub-segments into the final timeline list as individual conformed blocks with unique `sourceStart`/`sourceEnd` boundaries.
  - If no transients are found or for linear sections, pass the original linear boundaries as fallback.

### 4. Next.js API Master & Preview Routers

#### [MODIFY] [route.ts (Master)](file:///c:/Users/colds/Documents/GitHub/CineForge/src/app/api/render/route.ts) and [route.ts (Preview)](file:///c:/Users/colds/Documents/GitHub/CineForge/src/app/api/render/preview/route.ts)
- Implement a `cleanTitle` helper that checks if a block title matches structural placeholders (e.g., `"Intro Narrative Hook"`, `"Detail Sequence"`, `"Energy Build & Rise"`, `"Thematic Drop Climax"`, `"Visual CTA / Seamless Loop"`, etc.) and filters them out.
- This prevents the "Blueprint Burn-In" bug by only burning custom subtitles/captions onto the screen while keeping structural blocks text-free.
- Map speed ramp strings to aggressive velocity speed factors:
  - `"25%"` / `"quarter"` -> `0.25` (extreme slow-mo payoff)
  - `"50%"` / `"slow"` -> `0.5`
  - `"hyper"` / `"400%"` -> `4.0`
  - `"300%"` -> `3.0`
  - `"200%"` / `"fast"` -> `2.0`

---

## Verification Plan

### Automated Tests
- Run TypeScript compile validation across the workspace:
  ```bash
  cmd /c npx tsc --noEmit
  ```

### Manual Verification
- Dispatch a preview or a master render job of a gaming or sports clip.
- Play the output video to verify:
  1. The video jump-cuts dynamically to different parts of the raw media exactly on the audio beats.
  2. The pacing speeds up (e.g. 4.0x) and slows down (0.25x slow-mo) corresponding to the beats.
  3. No raw structural block titles (like "INTRO NARRATIVE HOOK") are burned onto the screen.
  4. The visual style uses a high-contrast dark aesthetic grade.
